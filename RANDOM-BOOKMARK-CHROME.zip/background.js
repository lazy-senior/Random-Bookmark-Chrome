var defaultSource = "history"; //bookmark, history or combined
var defaultSkin = "red"; //red, black, symbiose, classic

var maxHistoryResults = 100000; // TODO: implement in the CONFIGURATION PAGE 

function init(){

	localStorage.source 			= localStorage.source == undefined ? defaultSource : localStorage.source;
	localStorage.skin 				= localStorage.skin == undefined ? defaultSkin : localStorage.skin;
	localStorage.filteringEnabled	= localStorage.filteringEnabled == undefined ? "false" : localStorage.filteringEnabled;
	localStorage.filter 			= localStorage.filter == undefined ? JSON.stringify([{enabled : true, filter : "youtube.com"}]) : localStorage.filter;

	chrome.browserAction.setIcon({path:"skin/icon16-"+localStorage.skin+"-"+localStorage.source+".png"});
}
function isValidEntry(entry){
	if(localStorage.filteringEnabled === "true"){
		for(var i = 0; i < JSON.parse(localStorage.filter).length; i++){
			var obj = JSON.parse(localStorage.filter)[i];
			if(obj.enabled == true || JSON.parse(obj).enabled == true){
				var reg = JSON.parse(obj).enabled == true ? 
					new RegExp("^(http(s){0,1}://){0,1}(www.){0,1}("+JSON.parse(obj).filter+"){1}.*$") :
				 	new RegExp("^(http(s){0,1}://){0,1}(www.){0,1}("+obj.filter+"){1}.*$");
	         	if(reg.test(entry.url))
	            	return true;
	        }
		}
	}
	else
		return true;
	return false;
}

function getSubEntries(nodes, entries){
	nodes.forEach(function(nodes){
		if(nodes.children)
			entries.concat(getSubEntries(nodes.children, entries));
		else
			if (isValidEntry(nodes))
				entries.push(nodes);
	});
	return entries;
}

function getEntries(){
	if(localStorage.source == "bookmark"){
		chrome.bookmarks.getTree(function(nodes){
			displayRandomEntry(getSubEntries(nodes, new Array()));
		});
	}
	else if(localStorage.source == "history"){
		chrome.history.search({text: "", maxResults: maxHistoryResults}, function(historyResults){
			displayRandomEntry(getSubEntries(historyResults, new Array()));
		});
	}
	else{
		chrome.bookmarks.getTree(function(nodes){
			chrome.history.search({text: "", maxResults: maxHistoryResults}, function(historyResults){
				displayRandomEntry(getSubEntries(historyResults.concat(nodes), new Array()));
			});
		});
	}
}
function displayRandomEntry(entries){
	if(entries.length < 1){
		return;
	}
	chrome.windows.getLastFocused({populate: true}, function(window){
		window.tabs.forEach(function(tab){
			if(tab.active){
				chrome.tabs.update(tab.id, {url: entries[Math.floor(Math.random()*entries.length)].url});
				return;
			}
		});
	});
}


init();
chrome.browserAction.onClicked.addListener(getEntries);